<?php
get_header();

?>
<video autoplay muted loop style="
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
  min-width: 100%;
  min-height: 100%;
    ">
    <source src="<?php echo get_template_directory_uri(); ?>/assets/video/gl.webm" type="video/webm">
</video>
<div style="
backdrop-filter:blur(3px) brightness(0.75);
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background:rgba(0,0,0,0.4); 
    "></div>
<div style="position:relative; color:#dfdfdf;">
    <div class="d-flex justify-content-between flex-column" style="min-height: 100vh;">
        <div class="d-flex justify-content-center align-items-center flex-fill" >
            <center>
                <h1 class="theme-font big-font"><?php echo get_bloginfo('name'); ?></h1>
                <span><?php echo get_bloginfo('description'); ?></span>
                <br />
                <br />
                <div class="m-1 p-1">
                    ဒေါင်းလုပ်ယူပါ
                    <div class="grid my-1 py-1">
                        <button type="button" class="btn btn-primary"  style="margin: 0;padding:5px 10px;border:none;height:40px;"><i class="fa fa-android" style="font-size: large;"></i> Download</button>
                        <button type="button" class="btn btn-dark" style="margin: 0;padding:5px 10px;border:none;height:40px;"><img style="height:30px;" src="<?php echo get_template_directory_uri(); ?>/assets/images/google-play-badge.png" alt=""></button>
                    </div>
                </div>

            </center>
        </div>
        <div class="py-1">
			<center><h2>လျော့ဈေးပက်ကေ့ချ်များ</h2></center>
            <div id="secondary-slider" class="splide">
				<div class="splide__track">
					<ul class="splide__list">
					<?php
							$arg3 = array(
							// 'posts_per_page' => 7,
							// 'post_type' => 'post',
							// 'paged' => 1,
							// 'offset' => 5,
							'orderby' => 'date',
						);
						$q3 = new WP_Query( $arg3 );
						if ( $q3->have_posts() ) {
							while ( $q3->have_posts() ) {
								?>
								<li class="splide__slide mb-4">
								<?php
								$q3->the_post();
								get_template_part('content','card');
								?>
								</li>
								<?php
							}
						} else {
							// no posts found
						}?>
					</ul>
				</div>
			</div>
			<script>
				document.addEventListener( 'DOMContentLoaded', function () {
					new Splide( '#secondary-slider', {
						// type    : 'loop',
						fixedWidth  : 250,
						gap         : 10,
						cover       : true,
						isNavigation: true,
						focus       : 'center',
						autoplay: true,
						breakpoints : {
							'600': {
								fixedWidth: 200,
							}
						},
					} ).mount();
				} );
			</script>
        </div>
    </div>
</div>
<?php get_footer();?>