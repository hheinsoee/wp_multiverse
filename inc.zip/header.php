<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    wp_head();
    ?>
</head>

<body>
<?php // wp_body_open();
	?>
	<script>
		window.fbAsyncInit = function() {
			FB.init({
				appId: 'your-app-id',
				autoLogAppEvents: true,
				xfbml: true,
				version: 'v13.0'
			});
		};
	</script>
	<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js"></script>

    
    <div class="dropdown" style="position: fixed; right:10pt;top:10pt;z-index:9;">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="faqButton" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fa fa-question"></i> မေး
        </button>
        <ul class="dropdown-menu" aria-labelledby="faqButton">
            <?php
            foreach (hein_menu_array('help') as $menu_item) {

                $link = $menu_item->url;
                $title = $menu_item->title;

                if (!$menu_item->menu_item_parent) {
                ?>
                    <li class="item">
                        <a class="dropdown-item" href="<?php echo $link; ?>" class="title"><?php echo $title; ?> </a>
                    </li>
                <?php
                }
            };
                ?>
        </ul>

    </div>